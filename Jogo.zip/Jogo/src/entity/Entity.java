package entity;
//superclasse para os personagens do jogo
public class Entity {
    public int x, y;
    public int speed;
}
